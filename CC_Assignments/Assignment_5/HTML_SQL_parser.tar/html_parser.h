#ifndef HTML_PARSER_H
#define HTML_PARSER_H

void parse_html(const char *html);

void check_html_syntax(const char *html);

#endif